
from flask import Flask, request, jsonify
import pandas as pd
import os

app = Flask(__name__)
UPLOAD_DIR = os.environ.get("UPLOAD_DIR", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Simple in-memory "db"
DB = {
    "tank_base": [],
    "tank_history": [],
    "design_and_shell": [],
    "foundation_and_details": [],
    "roof_data": [],
    "roof_ut_quadrants": [],
    "shell_thickness_by_course": [],
    "nozzles_appurtenances": [],
    "mfe_summary": [],
    "nde_ut_record": [],
    "settlement_survey": [],
    "photo_log": [],
    "recommended_repairs": []
}

def allowed(name):
    return name in DB.keys()

@app.post("/import/<name>")
def import_csv(name):
    if not allowed(name):
        return jsonify({"error": f"unknown form '{name}'"}), 400
    if "file" not in request.files:
        return jsonify({"error": "no file uploaded"}), 400
    f = request.files["file"]
    path = os.path.join(UPLOAD_DIR, f.filename)
    f.save(path)
    try:
        df = pd.read_csv(path)
    except Exception as e:
        return jsonify({"error": f"failed to parse CSV: {e}"}), 400
    # persist to memory (replace for demo)
    DB[name] = df.to_dict(orient="records")
    return jsonify({"ok": True, "rows": len(DB[name])})

@app.get("/forms/<name>")
def get_data(name):
    if not allowed(name):
        return jsonify({"error": f"unknown form '{name}'"}), 400
    return jsonify(DB[name])

@app.post("/generate")
def generate_report():
    # TODO: run calcs (Shell RL, Floor MRT, Nozzle RL, Settlement) then build DOCX/PDF
    # For now, just report what we have
    counts = {k: len(v) for k, v in DB.items()}
    return jsonify({"status": "stub", "counts": counts})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
