
# OilPro Form Pack v1

These CSV templates mirror the sections and tables in your **Inspection Report (003)** so crews can enter data offline and you can import straight into the web app.

**What's inside**

- `tank_base.csv` — cover/tank data
- `tank_history.csv` — History Questionnaire (pages 2–3)
- `design_and_shell.csv` — Design & Shell info table (page 4)
- `foundation_and_details.csv` — Foundation/Details (page 5)
- `roof_data.csv` + `roof_ut_quadrants.csv` — Roof appurtenances & UT (pages 6–7)
- `shell_thickness_by_course.csv` — Shell course UT summary (page 28)
- `nozzles_appurtenances.csv` — Nozzle/Appurtenance table (page 27)
- `mfe_summary.csv` — MFL summary (pages 35–36)
- `nde_ut_record.csv` — UT technique record (page 37)
- `settlement_survey.csv` — survey points/corrections (see settlement section)
- `photo_log.csv` — photo pages (pages 41–43)
- `recommended_repairs.csv` — repairs pages (pages 44–49)

**Import guidance**

- Use plain numbers with US units unless specified (e.g., thickness in inches, heights in ft).
- Keep CSV headers unchanged.
- For nozzles, `shape_code` can be one of **A,B,C,D,E,F,G,H,J** as drawn in the form.

**Schemas**

Two JSON Schema examples are included (`*.schema.json`) to help validate inputs during import.

**Next**

Wire `/import/<name>` endpoints in your Replit app to accept these CSVs and map them to your data model. Then calculate Shell RL, Floor MRT, Nozzle RL, and Settlement cosine-fit before assembling the DOCX/PDF report.
