
# OilPro Tanks – “Whole Packet” (CSV-first)

This bundle contains:
- `api653_flat_schema.csv` — single-row, flat export/import for the report base + key summaries.
- `csv_templates/` — narrow CSVs that map 1:1 to your field forms for high‑density data.

## How to use

1) **Flat CSV**
   - Export a single row per report. Keep `report_number` consistent across all files.
   - Intended to mirror your Report Builder base page & summary fields.

2) **Detailed CSVs**
   - `shell_thickness_readings.csv` — add one row per course.
   - `floating_roof_rim.csv` — four rows (N/W/S/E).  
   - `floating_roof_deck.csv` — four rows (N/S/E/W), with UT measurements at Center, 11', 22', 33', 44'.
   - `nozzle_appurtenances.csv` — one row per nozzle/appurtenance.
   - `internal_bottom_survey.csv` — one row per radial; fill distances as measured.
   - `roof_seal_gaps.csv` — points A–P for primary/secondary seals, with gap & arc length.

3) **Import strategy**
   - Start by importing `api653_flat_schema.csv` to seed the base report.
   - Then import detailed CSVs; keep `report_number` as the join key.
   - Your server routes (in the patch) expose:
       - `GET /api/reports/:id/export.csv` — export the flat CSV
       - `GET /api/reports/:id/packet.zip` — zipped packet (flat CSV + generated XLSX template + any attachments)

4) **Notes**
   - Units: this schema assumes **US customary units** (ft / in / °F), matching your forms.
   - You can expand columns freely; the importer ignores unknown columns, so it’s forward‑compatible.
   - For shell courses, we include 10 slots in the flat schema. Use the detailed CSV if you need more.
   - Seal gap points A–P match your inspection sheets.

Generated: 2025-08-11T17:51:47
